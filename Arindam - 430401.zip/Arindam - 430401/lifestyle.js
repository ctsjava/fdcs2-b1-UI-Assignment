function validateForm(){
    var fname = myform.fname.value;

    if(fname.length==0){
        document.getElementById('fnameErrorMsg').innerHTML="First name mandatory";
        return false;
    }else{
        document.getElementById('fnameErrorMsg').innerHTML="";
    }

    return true;

}

function validateFormLname(){
    var lname = myform.lname.value;

    if(lname.length==0){
        document.getElementById('lnameErrorMsg').innerHTML="Last name mandatory";
        return false;
    }else{
        document.getElementById('lnameErrorMsg').innerHTML="";
    }

    return true;

}



var person = {
    pName: 'Praveen',
    sayName: function () {
            console.log('im ' + person.pName);
    }
};

var p = person;
person = { pName: 'Ria' };
p.sayName();

document.getElementById("demo").innerHTML = "Hello World!";